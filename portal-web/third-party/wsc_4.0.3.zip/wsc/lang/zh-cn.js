﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'zh-cn', {
	btnIgnore: '忽略',
	btnIgnoreAll: '全部忽略',
	btnReplace: '替换',
	btnReplaceAll: '全部替换',
	btnUndo: '撤消',
	changeTo: '更改为',
	errorLoading: '加载应该服务主机时出错: %s.',
	ieSpellDownload: '拼写检查插件还没安装, 您是否想现在就下载?',
	manyChanges: '拼写检查完成: 更改了 %1 个单词',
	noChanges: '拼写检查完成: 没有更改任何单词',
	noMispell: '拼写检查完成: 没有发现拼写错误',
	noSuggestions: '- 没有建议 -',
	notAvailable: '抱歉, 服务目前暂不可用',
	notInDic: '没有在字典里',
	oneChange: '拼写检查完成: 更改了一个单词',
	progress: '正在进行拼写检查...',
	title: '拼写检查',
	toolbar: '拼写检查'
});
