﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'bg', {
	btnIgnore: 'Игнорирай',
	btnIgnoreAll: 'Игнорирай всичко',
	btnReplace: 'Препокриване',
	btnReplaceAll: 'Препокрий всичко',
	btnUndo: 'Възтанови',
	changeTo: 'Промени на',
	errorLoading: 'Error loading application service host: %s.',
	ieSpellDownload: 'Spell checker not installed. Do you want to download it now?',
	manyChanges: 'Spell check complete: %1 words changed',
	noChanges: 'Spell check complete: No words changed',
	noMispell: 'Spell check complete: No misspellings found',
	noSuggestions: '- Няма препоръчани -',
	notAvailable: 'Съжаляваме, но услугата не е достъпна за момента',
	notInDic: 'Не е в речника',
	oneChange: 'Spell check complete: One word changed',
	progress: 'Проверява се правописа...',
	title: 'Проверка на правопис',
	toolbar: 'Проверка на правопис'
});
