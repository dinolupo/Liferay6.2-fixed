﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'zh-cn', {
	btn_about: '关于即时拼写检查',
	btn_dictionaries: '字典',
	btn_disable: '禁用即时拼写检查',
	btn_enable: '启用即时拼写检查',
	btn_langs:'语言',
	btn_options: '选项',
	text_title:  '即时拼写检查'
});
