﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'et', {
	btnIgnore: 'Ignoreeri',
	btnIgnoreAll: 'Ignoreeri kõiki',
	btnReplace: 'Asenda',
	btnReplaceAll: 'Asenda kõik',
	btnUndo: 'Võta tagasi',
	changeTo: 'Muuda',
	errorLoading: 'Viga rakenduse teenushosti laadimisel: %s.',
	ieSpellDownload: 'Õigekirja kontrollija ei ole paigaldatud. Soovid sa selle alla laadida?',
	manyChanges: 'Õigekirja kontroll sooritatud: %1 sõna muudetud',
	noChanges: 'Õigekirja kontroll sooritatud: ühtegi sõna ei muudetud',
	noMispell: 'Õigekirja kontroll sooritatud: õigekirjuvigu ei leitud',
	noSuggestions: '- Soovitused puuduvad -',
	notAvailable: 'Kahjuks ei ole teenus praegu saadaval.',
	notInDic: 'Puudub sõnastikust',
	oneChange: 'Õigekirja kontroll sooritatud: üks sõna muudeti',
	progress: 'Toimub õigekirja kontroll...',
	title: 'Õigekirjakontroll',
	toolbar: 'Õigekirjakontroll'
});
