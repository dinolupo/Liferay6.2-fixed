﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'af', {
	btnIgnore: 'Ignoreer',
	btnIgnoreAll: 'Ignoreer alles',
	btnReplace: 'Vervang',
	btnReplaceAll: 'vervang alles',
	btnUndo: 'Ontdoen',
	changeTo: 'Verander na',
	errorLoading: 'Fout by inlaai van diens: %s.',
	ieSpellDownload: 'Speltoetser is nie geïnstalleer nie. Wil u dit nou aflaai?',
	manyChanges: 'Klaar met speltoets: %1 woorde verander',
	noChanges: 'Klaar met speltoets: Geen woorde verander nie',
	noMispell: 'Klaar met speltoets: Geen foute nie',
	noSuggestions: '- Geen voorstel -',
	notAvailable: 'Jammer, hierdie diens is nie nou beskikbaar nie.',
	notInDic: 'Nie in woordeboek nie',
	oneChange: 'Klaar met speltoets: Een woord verander',
	progress: 'Spelling word getoets...',
	title: 'Speltoetser',
	toolbar: 'Speltoets'
});
