﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'sk', {
	btnIgnore: 'Ignorovať',
	btnIgnoreAll: 'Ignorovať všetko',
	btnReplace: 'Prepísat',
	btnReplaceAll: 'Prepísat všetko',
	btnUndo: 'Späť',
	changeTo: 'Zmeniť na',
	errorLoading: 'Chyba pri načítaní slovníka z adresy: %s.',
	ieSpellDownload: 'Kontrola pravopisu nie je naištalovaná. Chcete ju teraz stiahnuť?',
	manyChanges: 'Kontrola pravopisu dokončená: Bolo zmenených %1 slov',
	noChanges: 'Kontrola pravopisu dokončená: Neboli zmenené žiadne slová',
	noMispell: 'Kontrola pravopisu dokončená: Neboli nájdené žiadne chyby pravopisu',
	noSuggestions: '- Žiadny návrh -',
	notAvailable: 'Prepáčte, ale služba je momentálne nedostupná.',
	notInDic: 'Nie je v slovníku',
	oneChange: 'Kontrola pravopisu dokončená: Bolo zmenené jedno slovo',
	progress: 'Prebieha kontrola pravopisu...',
	title: 'Skontrolovať pravopis',
	toolbar: 'Kontrola pravopisu'
});
