﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'cy', {
	about: 'Ynghylch SCAYT',
	aboutTab: 'Ynghylch',
	addWord: 'Ychwanegu Gair',
	allCaps: 'Anwybyddu Geiriau Nodau Uwch i Gyd',
	dic_create: 'Creu',
	dic_delete: 'Dileu',
	dic_field_name: 'Enw\'r geiriadur',
	dic_info: 'Ar y cychwyn, caiff y Geiriadur ei storio mewn Cwci. Er, mae terfyn ar faint cwcis. Pan fydd Gweiriadur Defnyddiwr yn tyfu tu hwnt i gyfyngiadau maint Cwci, caiff y geiriadur ei storio ar ein gweinydd ni. er mwyn storio eich geiriadur poersonol chi ar ein gweinydd, bydd angen i chi osod enw ar gyfer y geiriadur. Os oes geiriadur \'da chi ar ein gweinydd yn barod, teipiwch ei enw a chliciwch y botwm Adfer.',
	dic_rename: 'Ailenwi',
	dic_restore: 'Adfer',
	dictionariesTab: 'Geiriaduron',
	disable: 'Analluogi SCAYT',
	emptyDic: 'Ni ddylai enw\'r geiriadur fod yn wag.',
	enable: 'Galluogi SCAYT',
	ignore: 'Anwybyddu',
	ignoreAll: 'Anwybyddu pob',
	ignoreDomainNames: 'Anwybyddu Enwau Parth',
	langs: 'Ieithoedd',
	languagesTab: 'Ieithoedd',
	mixedCase: 'Anwybyddu Geiriau â Chymysgedd Nodau Uwch ac Is',
	mixedWithDigits: 'Anwybyddu Geiriau â Rhifau',
	moreSuggestions: 'Awgrymiadau pellach',
	opera_title: 'Heb ei gynnal gan Opera',
	options: 'Opsiynau',
	optionsTab: 'Opsiynau',
	title: 'Gwirio\'r Sillafu Wrth Deipio',
	toggle: 'Togl SCAYT',
	noSuggestions: 'No suggestion'
});
