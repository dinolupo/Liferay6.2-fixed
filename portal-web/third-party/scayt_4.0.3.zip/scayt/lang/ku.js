﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'ku', {
	about: 'دهربارهی SCAYT',
	aboutTab: 'دهربارهی',
	addWord: 'زیادکردنی ووشه',
	allCaps: 'پشتگوێخستنی وشانهی پێکهاتووه لهپیتی گهوره',
	dic_create: 'درووستکردن',
	dic_delete: 'سڕینهوه',
	dic_field_name: 'ناوی فهرههنگ',
	dic_info: 'لهبنچینهدا فهرههنگی بهکارهێنهر کۆگاکردن کراوه له شهکرۆکه Cookie, ههرچۆنێك بێت شهکۆرکه سنووردار کراوه له قهباره کۆگاکردن.کاتێك فهرههنگی بهکارهێنهر گهیشته ئهم خاڵهی کهناتوانرێت زیاتر کۆگاکردن بکرێت له شهکرۆکه، ئهوسا فهرههنگهکه پێویسته کۆگابکرێت له ڕاژهکهی ئێمه. بۆ کۆگاکردنی زانیاری تایبهتی فهرههنگهکه له ڕاژهکهی ئێمه, پێویسته ناوێك ههڵبژێریت بۆ فهرههنگهکه. گهر تۆ فهرههنگێکی کۆگاکراوت ههیه, تکایه ناوی فهرههنگهکه بنووسه وه کلیکی دوگمهی گهڕاندنهوه بکه.',
	dic_rename: 'گۆڕینی ناو',
	dic_restore: 'گهڕاندنهوه',
	dictionariesTab: 'فهرههنگهکان',
	disable: 'ناچالاککردنی SCAYT',
	emptyDic: 'ناوی فهرههنگ نابێت خاڵی بێت.',
	enable: 'چالاککردنی SCAYT',
	ignore: 'پشتگوێخستن',
	ignoreAll: 'پشتگوێخستنی ههمووی',
	ignoreDomainNames: 'پشتگوێخستنی دۆمهین',
	langs: 'زمانهکان',
	languagesTab: 'زمانهکان',
	mixedCase: 'پشتگوێخستنی وشانهی پێکهاتووه لهپیتی گهورهو بچووك',
	mixedWithDigits: 'پشتگوێخستنی وشانهی پێکهاتووه لهژماره',
	moreSuggestions: 'پێشنیاری زیاتر',
	opera_title: 'پشتیوانی نهکراوه لهلایهن Opera',
	options: 'ههڵبژارده',
	optionsTab: 'ههڵبژارده',
	title: 'پشکنینی نووسه لهکاتی نووسین',
	toggle: 'گۆڕینی SCAYT',
	noSuggestions: 'No suggestion'
});
