﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'eo', {
	about: 'Pri OKDVT',
	aboutTab: 'Pri',
	addWord: 'Almeti la vorton',
	allCaps: 'Ignori la vortojn skribitajn nur per ĉefliteroj',
	dic_create: 'Krei',
	dic_delete: 'Forigi',
	dic_field_name: 'Vortaronomo',
	dic_info: 'Komence la vortaro de la uzanto estas konservita en kuketo. Tamen la kuketgrando estas limigita. Kiam la vortaro de la uzanto atingas grandon, kiu ne plu ebligas konservi ĝin en kuketo, tiam la vortaro povas esti konservata en niaj serviloj. Por konservi vian personan vortaron en nian servilon, vi devas indiki nomon por tiu vortaro. Se vi jam havas konservitan vortaron, bonvolu entajpi ties nomon kaj alklaki la restaŭrbutonon.',
	dic_rename: 'Renomi',
	dic_restore: 'Restaŭri',
	dictionariesTab: 'Vortaroj',
	disable: 'Malebligi OKDVT',
	emptyDic: 'La vortaronomo ne devus esti malplena.',
	enable: 'Ebligi OKDVT',
	ignore: 'Ignori',
	ignoreAll: 'Ignori ĉion',
	ignoreDomainNames: 'Ignori domajnajn nomojn',
	langs: 'Lingvoj',
	languagesTab: 'Lingvoj',
	mixedCase: 'Ignori vortojn kun miksa uskleco',
	mixedWithDigits: 'Ignori vortojn kun nombroj',
	moreSuggestions: 'Pli da sugestoj',
	opera_title: 'Ne subportata de Opera',
	options: 'Opcioj',
	optionsTab: 'Opcioj',
	title: 'OrtografiKontrolado Dum Vi Tajpas (OKDVT)',
	toggle: 'Baskuligi OKDVT',
	noSuggestions: 'No suggestion'
});
